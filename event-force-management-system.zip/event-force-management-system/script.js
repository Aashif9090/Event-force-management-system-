const defaultEvents=[
 {name:"Tech Fest 2026",date:"2026-10-20",location:"Main Auditorium",force:25,status:"Active"},
 {name:"Cultural Night",date:"2026-11-05",location:"Open Ground",force:40,status:"Planned"},
 {name:"Sports Meet",date:"2026-11-18",location:"College Stadium",force:30,status:"Planned"}
];
const defaultMembers=[
 {name:"Arun Kumar",role:"Team Leader",phone:"9876543210",status:"Available"},
 {name:"Priya S",role:"Security Coordinator",phone:"9876543211",status:"Deployed"},
 {name:"Vignesh R",role:"Volunteer",phone:"9876543212",status:"Available"},
 {name:"Harish M",role:"Medical Support",phone:"9876543213",status:"Available"}
];
let events=JSON.parse(localStorage.getItem("ef_events"))||defaultEvents;
let members=JSON.parse(localStorage.getItem("ef_members"))||defaultMembers;

function save(){localStorage.setItem("ef_events",JSON.stringify(events));localStorage.setItem("ef_members",JSON.stringify(members))}
function render(){
 document.getElementById("eventCount").textContent=events.length;
 document.getElementById("memberCount").textContent=members.length;
 document.getElementById("availableCount").textContent=members.filter(m=>m.status==="Available").length;
 document.getElementById("activeCount").textContent=events.filter(e=>e.status==="Active").length;
 document.getElementById("eventTable").innerHTML=events.map((e,i)=>`<tr><td><b>${e.name}</b></td><td>${e.date}</td><td>${e.location}</td><td>${e.force}</td><td><span class="status ${e.status.toLowerCase()}">${e.status}</span></td><td><button class="danger" onclick="deleteEvent(${i})">Delete</button></td></tr>`).join("");
 document.getElementById("teamGrid").innerHTML=members.map((m,i)=>`<div class="member"><div class="avatar">${m.name.split(" ").map(x=>x[0]).join("").slice(0,2)}</div><h3>${m.name}</h3><p>${m.role}</p><p>📞 ${m.phone}</p><p><b>${m.status}</b></p><button class="danger" onclick="deleteMember(${i})">Remove</button></div>`).join("");
}
function openEventModal(){
 document.getElementById("modalTitle").textContent="Add Event";
 document.getElementById("modalForm").innerHTML=`<div class="form-group"><label>Event Name</label><input id="f1" required></div><div class="form-group"><label>Date</label><input id="f2" type="date" required></div><div class="form-group"><label>Location</label><input id="f3" required></div><div class="form-group"><label>Force Members</label><input id="f4" type="number" min="1" required></div><div class="form-group"><label>Status</label><select id="f5"><option>Planned</option><option>Active</option><option>Completed</option></select></div><button class="submit">Save Event</button>`;
 document.getElementById("modalForm").onsubmit=e=>{e.preventDefault();events.push({name:f1.value,date:f2.value,location:f3.value,force:Number(f4.value),status:f5.value});save();render();closeModal()};
 document.getElementById("modal").classList.remove("hidden");
}
function openMemberModal(){
 document.getElementById("modalTitle").textContent="Add Force Member";
 document.getElementById("modalForm").innerHTML=`<div class="form-group"><label>Name</label><input id="f1" required></div><div class="form-group"><label>Role</label><input id="f2" required></div><div class="form-group"><label>Phone</label><input id="f3" required></div><div class="form-group"><label>Status</label><select id="f4"><option>Available</option><option>Deployed</option></select></div><button class="submit">Save Member</button>`;
 document.getElementById("modalForm").onsubmit=e=>{e.preventDefault();members.push({name:f1.value,role:f2.value,phone:f3.value,status:f4.value});save();render();closeModal()};
 document.getElementById("modal").classList.remove("hidden");
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
function deleteEvent(i){if(confirm("Delete this event?")){events.splice(i,1);save();render()}}
function deleteMember(i){if(confirm("Remove this member?")){members.splice(i,1);save();render()}}
function scrollToSection(id){document.getElementById(id).scrollIntoView({behavior:"smooth"})}
render();
